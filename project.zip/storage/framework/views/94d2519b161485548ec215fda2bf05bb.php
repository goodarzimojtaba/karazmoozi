<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تکمیل اطلاعات پروفایل</title>
    <link rel="stylesheet" href="https://yarjani19.com/assets/style_mobile.css">
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="" alt="">
        </div>
        <style>
            @font-face {
                font-family: "Vazir";
                src: url("https://yarjani19.com/mark/fonts/Vazir.ttf")format("Truetype");
                src: url("https://yarjani19.com/mark/fonts/Vazir.woff")format("woff");
                src: url("https://yarjani19.com/mark/fonts/Vazir.woff2")format("woff2");
            }
            </style>
        <h2 style="font-family:Vazir">تکمیل پروفایل</h2>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label style="font-family:Vazir"><?php echo e($error); ?></label>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <form method="POST" action="<?php echo e(route('verification')); ?>">
            <?php echo csrf_field(); ?>
            <label style="font-family:Vazir">کد ملی</label>
            <input type="text" name="code_melli" maxlength="10" style="font-family:Vazir" value="<?php echo e($user->code_melli); ?>" placeholder="کد ملی" readonly>
            
            <label style="font-family:Vazir" >نام و نام خانوادگی</label>
            <div class="password-container">
                <input type="text" name="name" style="font-family:Vazir" value="<?php echo e(old('name')); ?>" placeholder="" required>
                <i class="fas fa-eye-slash"></i>
                <label style="font-family:Vazir" >پایه</label>
            <div class="password-container">
                <input type="text" name="grade"  style="font-family:Vazir" value="<?php echo e(old('grade')); ?>" placeholder="مثال: دهم" required>
                <i class="fas fa-eye-slash"></i>
                <label style="font-family:Vazir" >رشته</label>
            <div class="password-container">
                <input type="text" name="major"  style="font-family:Vazir" value="<?php echo e(old('major')); ?>" placeholder="مثال: مکانیک" required>
                <i class="fas fa-eye-slash"></i>
                <label style="font-family:Vazir" >موبایل پدر</label>
            <div class="password-container">
                <input type="text" name="mobile_father" maxlength="11"  style="font-family:Vazir" value="<?php echo e(old('mobile_father')); ?>" placeholder="موبایل پدر" required>
                <i class="fas fa-eye-slash"></i>
                <label style="font-family:Vazir" >موبایل مادر</label>
            <div class="password-container">
                <input type="text" name="mobile_mother" maxlength="11" style="font-family:Vazir" value="<?php echo e(old('mobile_mother')); ?>" placeholder="موبایل مادر" required>
                <i class="fas fa-eye-slash"></i>
            </div>


            <button style="font-family:Vazir" type="submit" name="submit" class="signup-btn">بروزرسانی اطلاعات</button>
        </form>
    </div>
</body>
</html>
<?php /**PATH G:\Laravel\Poodeman\poodeman\resources\views\profile.blade.php ENDPATH**/ ?>