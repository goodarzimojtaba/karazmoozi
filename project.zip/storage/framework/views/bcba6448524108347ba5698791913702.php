<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>خطا</title>
    <link rel="stylesheet" href="https://yarjani19.com/assets/style_mobile.css">
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="" alt="">
        </div>
        <style>
            @font-face {
                font-family: "Vazir";
                src: url("https://yarjani19.com/mark/fonts/Vazir.ttf")format("Truetype");
                src: url("https://yarjani19.com/mark/fonts/Vazir.woff")format("woff");
                src: url("https://yarjani19.com/mark/fonts/Vazir.woff2")format("woff2");
            }
            </style>
        <h2 style="font-family:Vazir;color:green;">اطلاعات شما ثبت شده است</h2>
        <a style="font-family:Vazir" href="<?php echo e(route('show_data')); ?>" name="submit" class="signup-btn">مشاهده اطلاعات ثبت شده</a>

            
    </div>
</body>
</html>
<?php /**PATH G:\Laravel\Poodeman\poodeman\resources\views/error.blade.php ENDPATH**/ ?>