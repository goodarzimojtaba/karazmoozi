<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\play;

Route::get('/', function () {
    return view('welcome');
});
Route::get('/enter_form',[play::class,'start_app']);
Route::POST('/enter_form',[play::class,'login'])->name('login');
Route::get('/account',[play::class,'panel'])->name('pp');
Route::get('/karamoozi_form',[play::class,'karamoozi_page'])->name('karamoozi');
Route::POST('/karamoozi_form',[play::class,'karamoozi_validation'])->name('valid_karamoozi');
