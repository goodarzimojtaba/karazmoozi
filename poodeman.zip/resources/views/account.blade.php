<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>حساب کاربری</title>
    <link rel="stylesheet" href="https://yarjani19.com/assets/account.css">
</head>
<body>
<style>
            @font-face {
                font-family: "Vazir";
                src: url("https://yarjani19.com/mark/fonts/Vazir.ttf")format("Truetype");
                src: url("https://yarjani19.com/mark/fonts/Vazir.woff")format("woff");
                src: url("https://yarjani19.com/mark/fonts/Vazir.woff2")format("woff2");
            }
            </style>
    <div class="container">
        <header>
            <h1 style="font-family:Vazir">پنل کاربری</h1>
        </header>
        <div class="profile">
            <div class="info">
                <h2 style="font-family:Vazir">{{$user->code_melli}}</h2>
                <p style="font-family:Vazir">{{$user->name}}</p>
                <h4 style="font-family:Vazir;color:red;">خروج از سامانه</h4>
            </div>
        </div>
        <div class="menu">
            <div class="menu-item">
                <i class="fas fa-cog"></i>
                <div>
                    <h3 style="font-family:Vazir">درخواست ها</h3>
                    <p style="font-family:Vazir">گواهی اشتغال به تحصیل</p>
                </div>
            </div>
            <div class="menu-item">
                <i class="fas fa-lock"></i>
                <div>
                    <h3 style="font-family:Vazir">کارآموزی</h3>
                    <a href="{{route('karamoozi')}}" style="font-family:Vazir">ثبت اطلاعات کارآموزی</a>
                </div>
            </div>
            <div class="menu-item">
                <i class="fas fa-plug"></i>
                <div>
                <h3 style="font-family:Vazir">پیامک</h3>
                    <span style="font-family:Vazir">فعالسازی سرویس پیامکی</span>
                </div>
            </div>
            <div class="menu-item">
                <i class="fas fa-comments"></i>
                <div>
                <h3 href="" style="font-family:Vazir"> پروفایل</h3>
                <a href="" style="font-family:Vazir">تکمیل پروفایل</a>
                </div>
            </div>
        </div>
        <footer>
            <p style="font-family:Vazir">طراحی و توسعه هنرستان شهید یارجانی</p>
        </footer>
    </div>
</body>
</html>